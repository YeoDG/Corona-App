package com.example.messageinbottle.datamodel

import android.app.Activity
import android.location.Geocoder
import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import com.example.messageinbottle.MainActivity
import com.example.messageinbottle.chaeckDanget
import org.jetbrains.anko.doAsync
import org.jsoup.Jsoup
import org.jsoup.nodes.Element

class CoronaDTO {

    lateinit var geocoder : Geocoder
    var latitude : Double = 0.0;
    var longitude : Double = 0.0;

    var coronaMutableList : MutableLiveData<ArrayList<GpsModel>> =MutableLiveData<ArrayList<GpsModel>>()
    var coronaLocationList : ArrayList<GpsModel> = ArrayList<GpsModel>()

    val dataObserver: Observer<ArrayList<GpsModel>> =
        Observer { livedata ->  coronaLocationList = livedata
            println("확진자 데이터 변경")
            chaeckDanget()
        }





    fun setInit(activity : Activity){
        geocoder  = Geocoder(activity)
        doAsync {
            println("코로나 확진자 확인")

            //대구시 코로나 확진자 url
            var url: String = "http://covid19.daegu.go.kr/00937400.html"
            var doc = Jsoup.connect(url).get()
            val tbody = doc.select("tbody")[1]
            val rows = tbody.select("tr")
            var body : Element? = null
            var code : String? = null
            var start : String? = null
            var end : String? = null

            var list : ArrayList<GpsModel> = ArrayList<GpsModel>()

            for (i in 1..rows.size-1){
                var gpsModel: GpsModel = GpsModel();
                //주소
                body = tbody.select("tr")[i].select("td").select("p")[4]
                code = body.toString().replace("<p>", "").replace("<br></p>", "").replace("</p>", "")
                gpsModel.adress = code
                //경도위도
                latitude = geocoder.getFromLocationName(code, 1)?.get(0)?.latitude!!
                longitude = geocoder.getFromLocationName(code, 1)?.get(0)?.longitude!!
                gpsModel.locationX = latitude
                gpsModel.locationY = longitude
                //노출시간
                body = tbody.select("tr")[i].select("td").select("p")[5]
                code = body.toString()
                    .replace("<p>", "").replace("<br></p>", "").replace("</p>", "")
                    .replace(".(", "").replace(")", "").replace(",", "")
                    .replace("월", "").replace("화", "").replace("수", "").replace("목", "")
                    .replace("금", "").replace("토", "").replace("일", "")
                    .replace("&nbsp;", "").replace("(", "")
                    .replace("\\d\\d:\\d\\d".toRegex(), "").replace(" ", "")
                //시작 날짜 출력
                start = code.toString().replaceAfter("~", "").replace("~", "")
                gpsModel.arrivalDate = start.toString()
                //끝 날짜 출력
                end = code.toString().replaceBefore("~", "").replace("~", "")
                if (end == "") //끝 날짜 없을시 시작 날짜로 출력
                    gpsModel.arrivalDate = start.toString()
                else
                    gpsModel.arrivalDate = end.toString()
                list.add(gpsModel)
            }
            Log.d("coronalist : ",""+list);

            coronaMutableList.postValue(list)


        }
    }

}
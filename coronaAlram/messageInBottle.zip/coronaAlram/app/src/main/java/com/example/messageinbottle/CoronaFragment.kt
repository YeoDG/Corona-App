package com.example.messageinbottle

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.messageinbottle.base.BaseFragment
import com.example.messageinbottle.base.BaseRecyclerAdapter
import com.example.messageinbottle.databinding.FragmentCoronaBinding
import com.example.messageinbottle.databinding.ItemCoronalistBinding
import com.example.messageinbottle.datamodel.GpsModel
import org.json.JSONException
import org.json.JSONObject
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStream
import java.io.InputStreamReader
import java.net.MalformedURLException
import java.net.URL

class CoronaFragment : BaseFragment<FragmentCoronaBinding>(R.layout.fragment_corona) {


    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        super.onCreateView(inflater, container, savedInstanceState)
        binding.coronafragment = this



        return binding.root
    }
}

package com.example.messageinbottle


import android.content.*
import android.net.Uri
import android.os.Bundle
import android.preference.PreferenceManager
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import androidx.lifecycle.lifecycleScope
import com.example.messageinbottle.base.BaseActivity
import com.example.messageinbottle.base.BaseRecyclerAdapter
import com.example.messageinbottle.databinding.ActivityMainBinding
import com.example.messageinbottle.databinding.ItemCoronalistBinding
import com.example.messageinbottle.datamodel.*
import com.example.messageinbottle.gps.GpsBackgroundService
import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.PermissionRequest
import com.karumi.dexter.listener.multi.MultiplePermissionsListener
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode


class MainActivity() : BaseActivity<ActivityMainBinding>(R.layout.activity_main) , SharedPreferences.OnSharedPreferenceChangeListener {

    companion object {
        var gpsDTO: GpsDTO = GpsDTO()
        var userDTO:UserDTO = UserDTO()
        var firebaseDTO:FirebaseDTO = FirebaseDTO()
        var coronaDTO:CoronaDTO = CoronaDTO()
    }

    //현재 유저 uid

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding.mainactivity = this;

        Dexter.withActivity(this).withPermissions(android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION, android.Manifest.permission.ACCESS_BACKGROUND_LOCATION) // 위치
            .withListener(object : MultiplePermissionsListener {
                override fun onPermissionsChecked(multiplePermissionsReport: MultiplePermissionsReport) { // 권한 여부를 다 묻고 실행되는 메소드
                    println("퍼미션 전부 허용 완료")
                    bindService(Intent(this@MainActivity, GpsBackgroundService::class.java),gpsDTO.mServiceConnection, Context.BIND_AUTO_CREATE)
                    lifecycleScope.launch {
                        firebaseDTO.getUser().collect {
                            Log.d("it ? : ",""+it);
                            userDTO.coronaList.postValue(it)
                            gpsDTO.mService!!.requestLocationUpdate()
                        }
                    }
                }
                override fun onPermissionRationaleShouldBeShown(list: List<PermissionRequest>, permissionToken: PermissionToken) {
                    // 이전 권한 여부를 거부한 권한이 있으면 실행되는 메소드
                    // 파라미터로 전달된 list : 거부한 권한 이름이 저장되어 있습니다.
                }
            }).check()

        coronaDTO.coronaMutableList.observe(this, coronaDTO.dataObserver)
        println("확진자 리스트 확인")
        coronaDTO.setInit(this);

        supportFragmentManager.beginTransaction().replace(R.id.mainFragment, UserFragment()).commit()
    }

    //카테고리 이동 함수
    fun changeFragment(view : View,value : Int){
        when(value){
            1 -> supportFragmentManager.beginTransaction().replace(R.id.mainFragment, UserFragment()).commit()
            2 -> supportFragmentManager.beginTransaction().replace(R.id.mainFragment, CoronaFragment()).commit()
            3 -> openNaver()
        }
    }

    fun openNaver(){
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://nid.naver.com/login/privacyQR?term=on"))
        startActivity(intent)
    }

    @Subscribe(sticky = true,threadMode = ThreadMode.MAIN)
    fun onListenLocation(event : GpsBackgroundService.SendLocationToActivity){
//        if(event != null){
//            var date : String = StringBuilder("" + event.getLoction().latitude).append("/").append(event.getLoction().longitude).toString()
//            Toast.makeText(gpsDTO.mService,date, Toast.LENGTH_SHORT).show()
//        }
    }

    override fun onStart() {
        super.onStart()
        PreferenceManager.getDefaultSharedPreferences(this).registerOnSharedPreferenceChangeListener(this)
        EventBus.getDefault().register(this)
    }


    override fun onStop() {
        if(gpsDTO.mBound){
            unbindService(gpsDTO.mServiceConnection)
            gpsDTO.mBound = false
        }
        PreferenceManager.getDefaultSharedPreferences(this).unregisterOnSharedPreferenceChangeListener(this)
        EventBus.getDefault().unregister(this)
        super.onStop()
    }


    override fun onSharedPreferenceChanged(sharedPreferences: SharedPreferences?, key: String?) {}

}


var DangerCount: MutableLiveData<Int> = MutableLiveData()

//위험군 확인
public fun chaeckDanget() : Boolean {
    println(" 위험 검사 ")

    var flag : Boolean = false;
    var dangerCount = 0
    for (i in MainActivity.userDTO.coronaObserverList){
        for(j in MainActivity.coronaDTO.coronaLocationList){
            var width : Double = (Math.abs(i.locationX!!-j.locationX!!)*10000)
            var height : Double = (Math.abs(i.locationY!!-j.locationY!!)*10000)
            var distance = Math.sqrt(width*width +height*height)

            println(" 주소 비교 : " + i.adress + " / " + j.adress + " / " + distance)
            println(" 시간 비교 : " + i.arrivalDate + " / " + j.leaveData + "   ||   " +  i.leaveData + " / " + j.arrivalDate)
            if(!(i.arrivalDate > j.leaveData)||(i.leaveData < j.arrivalDate)) {
                if (distance < 2.5) {
                    i.danger.set(true)
                    flag = true
                    dangerCount++
                }
            }
        }
    }
    DangerCount.value = dangerCount
    println(" 값 : " + DangerCount.value)
    return flag
}

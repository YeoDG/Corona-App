package com.example.messageinbottle.base

import android.graphics.Color
import android.view.View
import androidx.databinding.BindingAdapter
import com.google.firebase.database.collection.LLRBNode

object DataBindingAdapyter {
    //뷰보이기 안보이기
    @JvmStatic
    @BindingAdapter("dangercheck")
    fun setDanger(view: View, danger: Boolean) {
        println("위험 변화")
        if(danger == true){
            view.setBackgroundColor(Color.RED)
        }else{
            view.setBackgroundColor(Color.GRAY)
        }
    }
}
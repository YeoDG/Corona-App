package com.example.messageinbottle

import android.app.Activity
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.messageinbottle.base.BaseFragment
import com.example.messageinbottle.base.BaseRecyclerAdapter
import com.example.messageinbottle.databinding.FragmentUserBinding
import com.example.messageinbottle.databinding.ItemCoronalistBinding
import com.example.messageinbottle.datamodel.GpsDTO
import com.example.messageinbottle.datamodel.GpsModel
import com.example.messageinbottle.datamodel.UserDTO

class UserFragment() : BaseFragment<FragmentUserBinding>(R.layout.fragment_user) {


    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        super.onCreateView(inflater, container, savedInstanceState)
        binding.userFragment = this

        MainActivity.userDTO.coronaList.observe(this, dataObserver)
        DangerCount.observe(this, dangerObserver)

        binding.userMoveRoot.adapter = BaseRecyclerAdapter<GpsModel,ItemCoronalistBinding>(R.layout.item_coronalist,MainActivity.userDTO.coronaObserverList)
        binding.userMoveRoot.layoutManager = LinearLayoutManager(context, LinearLayoutManager.VERTICAL,false)

        return binding.root
    }

    val dataObserver: Observer<ArrayList<GpsModel>> =
        Observer {
                livedata ->  MainActivity.userDTO.coronaObserverList = livedata
            println("바뀐 데이터 : " + livedata)
            if(chaeckDanget() == false){
                println("유저 데이터 변경")
                binding.userMoveRoot.adapter = BaseRecyclerAdapter<GpsModel,ItemCoronalistBinding>(R.layout.item_coronalist,MainActivity.userDTO.coronaObserverList)
            }
        }

    val dangerObserver: Observer<Int> =
        Observer {
                livedata ->  binding.dangerCount.setText(livedata.toString())
        }


}
